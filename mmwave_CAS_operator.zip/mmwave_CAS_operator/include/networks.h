#ifndef _NETWORKS_H_
#define _NETWORKS_H_

#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <iostream>
#include <cstring>
#include <vector>
#include <unistd.h>
#include <typeinfo>
#include <iostream>

#define _RadarIP_ "127.0.0.1"
#define _RadarPort_ 9999
#define _ClientIP_ "127.0.0.1"
#define _ClientPort_ 6666
#define _PACKAGE_SIZE_ 1024

void openClient();
bool recvCmd();
bool replyCmd();
void requestCollectData(int time, std::string name);

#endif
