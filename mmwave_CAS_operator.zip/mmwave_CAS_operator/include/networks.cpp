#include "networks.h"

int clientSocket;
struct sockaddr_in server_;
struct sockaddr_in client_;
unsigned char cli_buff[_PACKAGE_SIZE_];

void openClient() //
{
    //建立一个数据报类型的UDP套接字  ******************//
    clientSocket = socket(PF_INET, SOCK_DGRAM, 0); //配置模式，
    client_.sin_family = AF_INET;
    client_.sin_addr.s_addr = inet_addr(_ClientIP_); //设置接收ip地址
    client_.sin_port = htons(_ClientPort_);	  //接收用的端口
    //设置服务器地址addrSrv和监听端口
    server_.sin_family = AF_INET;
    server_.sin_addr.s_addr = inet_addr(_RadarIP_); //设置服务器主机ip地址（与接收方客户端的IP对应）
    server_.sin_port = htons(_RadarPort_);	//发送用的端口，可以根据需要更改
    
    /*struct timeval tv;
    tv.tv_sec = 360;
    tv.tv_usec = 0;
    if (setsockopt(clientSocket, SOL_SOCKET, SO_RCVTIMEO,&tv,sizeof(tv)) < 0) {
        std::cout << "Build UDP Client: Timeout set failure" << std::endl;
    }*/
    
    while (true) {
        // connect UDP port
        int ret = bind(clientSocket, (sockaddr *)&client_, sizeof(client_));
        if (ret == -1){
            std::cout << "Build UDP Client: Client Build failure" << std::endl;
        }else{
            std::cout << "Build UDP Client: Client Build Success" << std::endl;
            break;
        }
        sleep(1); // try re-connect after 1 second
    }
}

bool recvCmd() //
{
    socklen_t len = sizeof(sockaddr);
    memset(cli_buff, 0, _PACKAGE_SIZE_);
    int ret = recvfrom(clientSocket, cli_buff,
             _PACKAGE_SIZE_, 0,
             (sockaddr *)&client_,  &len);
    if (ret < 0){
        std::cout << "recvCmd: Not received" << std::endl;
        return false;
    }
    return true;
}

bool replyCmd() //
{
    int t = sendto(clientSocket, cli_buff,
                   _PACKAGE_SIZE_, 0,
                   (sockaddr *)&server_, sizeof(server_));
	if (t < 0) {
        std::cout << "Send Reply Failure" << std::endl;
        memset(cli_buff, 0, _PACKAGE_SIZE_);
        return false;
    }
    memset(cli_buff, 0, _PACKAGE_SIZE_);
    return true;
}


void requestCollectData(int time, std::string name){
	memset(cli_buff, 0, _PACKAGE_SIZE_);
	cli_buff[0] = time & 0x000000FF;
	cli_buff[1] = time & 0x0000FF00;
	cli_buff[2] = time & 0x00FF0000;
	cli_buff[3] = time & 0xFF000000;
	replyCmd();
	// recv result
	recvCmd();
	if (cli_buff[0] != '0') {
	  std::cout << cli_buff << std::endl;
	  return;
	}
	memcpy(cli_buff, name.c_str(), name.size() > _PACKAGE_SIZE_ ? _PACKAGE_SIZE_ : name.size());
	replyCmd();
	recvCmd();
	if (cli_buff[0] != '0') {
	  std::cout << cli_buff << std::endl;
	  return;
	}
}
