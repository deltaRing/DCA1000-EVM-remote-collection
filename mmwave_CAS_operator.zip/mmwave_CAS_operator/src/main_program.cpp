#include <ros/ros.h>
#include <iostream>
#include <sstream>
#include <iomanip>
#include <string>
#include <chrono>
#include <mavros_msgs/CommandBool.h>
#include <mavros_msgs/SetMode.h>
#include <mavros_msgs/State.h>
#include <mavros_msgs/RCIn.h>		
#include "include/networks.h"				

#define _RC_HIGH_ 1750
#define _RC_MIDDLE_ 1500
#define _RC_LOW_ 1250
#define _RC_CONTROL_DCA1000_CHANNEL_ 10
mavros_msgs::State current_state; // current status of flight controller

void FC_callback(const mavros_msgs::RCIn::ConstPtr & msg){
	if (msg->rssi == 0) {
		return;
	}

	if (msg->channels[_RC_CONTROL_DCA1000_CHANNEL_] >= _RC_HIGH_){
		ROS_INFO("[node] Sending request");
		// try to get radar
		auto t = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());
		//转为字符串
 		std::stringstream ss;
	        // 可以分别以不同的形式进行显示
	        ss << std::put_time(std::localtime(&t), "%Y-%m-%d-%H-%M-%S");
	        std::string str = ss.str();
	        requestCollectData(1, str);
		//startRecord(cfg_file, str);
		ROS_INFO("[node] Sent request for recording data");
	}
}

void FC_status_callback(const mavros_msgs::State::ConstPtr & msg){
	current_state = *msg;
}

int main(int argc, char ** argv){
	ros::init(argc, argv, "radar_sample_main_program");
	ros::NodeHandle nh;
	
	ROS_INFO("Initializing Flight Controller Callback");
	ros::Subscriber state_sub    = nh.subscribe<mavros_msgs::State>("mavros/state", 10, FC_status_callback);
	ros::Subscriber rc_sub       = nh.subscribe<mavros_msgs::RCIn>("mavros/rc/in", 10, FC_callback);
	ros::Rate rate(10);
	
	// wait for fc's connection
	while (ros::ok() && !current_state.connected){
		ROS_INFO("Waiting for flight controller");
		ros::spinOnce();
		rate.sleep();
	}
	
	openClient();
	ROS_INFO("Establish main program Networks Complete");

	// if fc is connected
	// waiting RC
	while (ros::ok()){

		ros::spinOnce();
		rate.sleep();
	}	
	return 0;
}
